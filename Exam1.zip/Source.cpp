/*
Name: nathaniel A. Barnett
Date: 03/07/2016
Lab: Exam1
Algorithm:
1. Read in the two matrices from the input file and store them in
	two Matrix objects.
2. Add the two matrices together into a third object of type Matrix, 
	and store third array in a dynamic array.
3. Repeat steps previous two steps until there is no more to be read 
	in from the file.
4. Print the contents of the dynamic array to output file.
5. Close files.
*/

#include "Matrix.h"
#include <fstream>
#include <iostream>
using namespace std;

// Declaring functions
int resizeArray(Matrix* &oldArray, int oldSize);

void main()
{

	// input/output files
	ifstream fin("input.txt");
	ofstream fout("output.txt");

	// variables
	int m_rows, m_columns, m1_val;
	int m2_val, addVal, numOfArrays = 0;
	typedef Matrix* matrixptr;		// simplify naming of pointers
	int currentSize = 2;
	matrixptr M_array = new Matrix[currentSize];


	if (!fin || !fout)
	{
		cout << "Error opening files" << endl;
		system("pause");
		exit(1);
	}

	while (!fin.eof())
	{
		// create and populate matrix 1
		fin >> m_rows >> m_columns;
		Matrix M1(m_rows, m_columns);
		for (int r = 0; r < m_rows; r++)
		{
			for (int c = 0; c < m_columns; c++)
			{
				fin >> m1_val;
				M1.set(r, c, m1_val);
			}
		}
		
		//create and populate matrix 2
		Matrix M2(m_rows, m_columns);
		for (int r = 0; r < m_rows; r++)
		{
			for (int c = 0; c < m_columns; c++)
			{
				fin >> m2_val;
				M2.set(r, c, m2_val);
			}
		}

		//create a third matrix and populate it by adding the previous two matrices
		Matrix M3(m_rows, m_columns);
		for (int r = 0; r < m_rows; r++)
		{
			for (int c = 0; c < m_columns; c++)
			{
				addVal = M1.get(r, c) + M2.get(r, c);
				M3.set(r, c, addVal);
			}
		}

		// if dynamic array is to small, make bigger. if not, then skip.
		if (numOfArrays >= currentSize)
		{
			currentSize = resizeArray(M_array, currentSize);
		}

		// assign third matrix to dynamic array
		M_array[numOfArrays] = M3;
		numOfArrays++;
		//cout << M3.get(0, 0) << M3.get(0, 1) << M3.get(0, 2) << endl;

	}

	// print contents of dynamic array to screen.
	for (int i = 0; i < numOfArrays; i++)
	{
		for (int r = 0; r < M_array[i].getRows(); r++)
		{
			for (int c = 0; c < M_array[i].getColumns(); c++)
			{
				fout << M_array[i].get(r, c) << "\t";
			}
			fout << endl;
		}
		fout << endl;
	}

	// closing the door behind you...
	fout.close();
	fin.close();
}


int resizeArray(Matrix* &oldArray, int oldSize) // to make the array bigger if need be
{
	int newSize = oldSize * 2;
	Matrix *ptr = new Matrix[newSize];

	for (int i = 0; i < oldSize; i++)
	{
		ptr[i] = oldArray[i];
	}

	delete[] oldArray;
	oldArray = ptr;

	return newSize;
}
