/*
Name: nathaniel A. Barnett
Date: 03/07/2016
Lab: Exam1
*/

#include "Matrix.h"

Matrix::Matrix()	//Default Constructor
{
	rows = 50;
	columns = 50;
	matrix[50][50];
}

Matrix::Matrix(int row, int column)
{
	rows = row;
	columns = column;
	matrix[50][50];
}

void Matrix::set(int row, int column, int value)
{
	matrix[row][column] = value;
}

int Matrix::get(int row, int column)
{
	return matrix[row][column];
}

int Matrix::getRows()
{
	return rows;
}

int Matrix::getColumns()
{
	return columns;
}

