/*
Name: nathaniel A. Barnett
Date: 03/07/2016
Lab: Exam1
*/

#include <iostream>
#include <fstream>
using namespace std;

class Matrix
{
private:
	int rows, columns;
	int matrix[50][50];

public:
	Matrix();
	Matrix(int row, int coulmn);
	void set(int row, int column, int value);
	int get(int row, int column);
	int getRows();
	int getColumns();
};